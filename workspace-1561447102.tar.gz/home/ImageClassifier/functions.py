python train.py data_directory

python train.py data_dir --save_dir save_directory

python train.py data_dir --arch "vgg13"
python train.py data_dir --arch "vgg16"
python train.py data_dir --arch "resnet18"

python train.py data_dir --learning_rate 0.01 --hidden_units 512 --epochs 20

python train.py data_dir --gpu

import argparse
def get_input_args():
    
    parser = argparse.ArgumentParser()

    parser.add_argument('--dir' , type=str , default = 'flowers/train' , help='path to the folder pet images')
    parser.add_argument('--arch' , type=str , default = 'vgg13' , help='CNN model architecture')
    parser.add_argument('--learning_rate' , type=float , default = '0.01', help='learning rate')
    parser.add_argument('--hidden_units' , type=int , default = '512', help='Hidden units')
    parser.add_argument('--epochs' , type=int , default = '20', help='learning rate')
    
    in_args = parser.parse_args()
    
    return in_args
    
    
